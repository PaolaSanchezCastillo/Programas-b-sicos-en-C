//Programa 27, S�nchez Castillo Paola
#include<stdio.h>
#include<conio.h>
int lista[4];
main(){
       lista[0]=2;
       lista[1]=3;
       lista[2]=4;
       lista[3]=5;
       printf("Lista[0]=%i" ,lista[0]);
       printf("\nLista[1]=%i" ,lista[1]);
       printf("\nLista[2]=%i" ,lista[2]);
       printf("\nLista[3]=%i" ,lista[3]);
       getch();
}
