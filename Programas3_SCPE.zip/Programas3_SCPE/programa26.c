//Programa 26, S�nchez Castillo Paola
#include<stdio.h>
#include<conio.h>
float div(float r);
main(){
       div(1);
       getch();
}
float div(float r){
      float d1, d2;
      printf("introducir el valor del dividendo ");
      scanf("%f" ,&d1);
      printf("introducir el valor del divisor ");
      scanf("%f" ,&d2);
      r=d1/d2;
      printf("\n%.2f entre %.2f es: %.2f" ,d1,d2,r);
      }
