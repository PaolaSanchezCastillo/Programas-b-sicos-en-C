//Programa 30, S�nchez Castillo Paola
#include<stdio.h>
#include<conio.h>
int size, i;
main(){
       printf("introducir el tama�o del arreglo deseado\n");
       scanf("%i" ,&size);
       int arreglo[size];
       printf("introducir el valor especificado\n");
       for(i=0;i<size;i++){
                           printf("\nAreglo[%i]=",i);
                           scanf("%i" ,&arreglo[i]);
                           }
       printf("los valores del arreglo son:\n\n");
       for(i=0;i<size;i++){
                           printf("Arreglo[%i]=%i\n",i,arreglo[i]);
                           }
                           getch();
}
