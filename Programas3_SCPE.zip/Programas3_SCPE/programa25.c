//Programa 25, S�nchez Castillo Paola
#include<stdio.h>
#include<conio.h>
int suma(int a), cons=2, r;
main(){
       suma(1);
       getch();
}
int suma(int a){
    int b;
    printf("Ingresar los 2 numeros que se desean sumar: ");
    scanf("%i%i" ,&a,&b);
    r=a+b;
    printf("\nla suma de %i y %i es %i" ,a,b,r);
    printf("\nLa multiplicacion de la suma anterior por 2 es: %i" ,r*cons);
}
