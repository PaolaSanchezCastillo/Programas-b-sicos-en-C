//Programa 29, S�nchez Castillo Paola
#include<stdio.h>
#include<conio.h>
int lista[10]={1,2,3,4,5,6,7,8,9,10};
int i;
main(){
       for(i=0;i<10;i++){
                         printf("lista[%i]=%i\n" ,i,lista[i]);
                         }
getch();
}
