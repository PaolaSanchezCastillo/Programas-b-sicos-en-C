//Programa 28, S�nchez Castillo Paola
#include<stdio.h>
#include<conio.h>

main(){
       int lista[3]={1, 2, 3};
       printf("Lista[0]=%i\n" ,lista[0]);
       printf("Lista[1]=%i\n" ,lista[1]);
       printf("Lista[2]=%i\n" ,lista[2]);
       getch();
}
