//Programa 21, S�nchez Castillo Paola
#include<stdio.h>
#include<conio.h>
main(){
      int num, i, j, k;
      printf("ingresa el numero de lineas que deseas que tenga tu piramide: ");
      scanf("%i" ,&num);
      for(i=1;i<=num;i++){
                          for(j=1;j<=num-i;j++){
                                                printf(" ");
                                                }
                          for(k=1;k<=2*i-1;k++){
                                                  printf("*");
                                                  }
                          printf("\n");
                          }
getch();
}
