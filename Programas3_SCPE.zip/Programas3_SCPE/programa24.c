//Programa 24, S�nchez Castillo Paola
#include<stdio.h>
#include<conio.h>
int suma(int a), s;
main(){
       suma(1);
       getch();
}
int suma(int a){
    int b;
    printf("introducir los 2 valores a sumar: ");
    scanf("%i%i" ,&a,&b);
    s=a+b;
    printf("La suma de %i + %i es: %i" ,a,b,s);
}
