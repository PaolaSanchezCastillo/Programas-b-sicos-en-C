//Programa 23, S�nchez Castillo Paola
#include<stdio.h>
#include<conio.h>
int num, i;
int cubo(int base);
main(){
       printf("introduce el numero del que se desea obtener el cubo\n");
       scanf("%i" ,&num);
       printf("\nEl cubo del numero %i es: %i" ,num,cubo(1));
       getch();
}
int cubo(int base){
    int potencia;
    potencia=num*num*num;
    return potencia;
}
