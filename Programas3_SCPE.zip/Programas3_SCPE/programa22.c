//Programa 22, S�nchez Castillo Paola
#include<stdio.h>
#include<conio.h>
main(){
      int num, i, j, k, n;
      printf("ingresa el la altura de la piramide que forma la mitad de tu rombo: ");
      scanf("%i" ,&num);
      for(i=1;i<=num;i++){
                          for(j=1;j<=num-i;j++){
                                                printf(" ");
                                                }
                          for(k=1;k<=2*i-1;k++){
                                                  printf("*");
                                                  }
                          printf("\n");
                          }
      for(i=num;i>=1;i--){
                          for(j=1;j<=num-i;j++){
                                                printf(" ");
                                                }
                          for(k=1;k<=2*i-1;k++){
                                                  printf("*");
                                                  }
                          printf("\n");
                          }
getch();
}
