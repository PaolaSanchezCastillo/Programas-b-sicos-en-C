/*Fundamentos de programaci�n
  Programa 15-Conversi�n grados cent�grados
  a grados Fahrenheit y viceversa
   Autor: S�nchez Castillo Paola
  Semestre 2016-1 */

#include<stdio.h>

int opt;
float C, F;

/**Programa para convertir grados Cent�grados
** a grados Fahrenheit y viceversa **/

int main(void){

  printf("-------------------------------------------------------\n");
  printf("Programa para convertir grados Centigrados y Fahrenheit\n");
  printf("Elige el numero de la conversion que quieres realizar:\n\n"
         "1-Grados C a grados F\n\n"
         "2-Grados F a grados C\n\n");
  printf("-------------------------------------------------------\n");

  printf("Tu eleccion es: ");
  scanf("%i", &opt);
  printf("-------------------------------------------------------\n");

  switch(opt){
    case 1:
      printf("Ingresa los grados Centigrados: ");
      scanf("%f", &C);
      F = (C*9/5)+32;
      printf("\n%.3f grados C equivalen a %.3f grados F\n", C, F);
      break;
    case 2:
      printf("Ingresa los grados Fahrenheit: ");
      scanf("%f", &F);
      C = (F-32)*5/9;
      printf("\n%.3f grados F equivalen a %.3f grados C\n", F, C);
      break;
    default:
      printf("Opcion no valida\n");
  }
  printf("-------------------------------------------------------\n");
  return 0;
}

