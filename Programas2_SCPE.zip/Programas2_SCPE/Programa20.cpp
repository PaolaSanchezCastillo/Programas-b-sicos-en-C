/*Fundamentos de programaci�n
  Programa 20. Uso de Switch - Case
   Autor: S�nchez Castillo Paola
  Semestre 2016-1 */

#include <stdio.h>
#include<stdlib.h>
#include <conio.h>
#include  <math.h>

#define PI 3.14159265

float A, B, Resultado, Base, Pot=1, Angulo, Potencia(float Base), Seno(float Angulo), Coseno(float Angulo), Tangente(float Angulo);
float Suma(float A), Resta(float A), Producto(float A), Cociente(float A), Arcoseno(float A), Arcocoseno(float A), Arcotangente(float A);
int Ch, Num, i, Fact=1, Exponente, Factorial(int Num);
main(){
	printf("\n------------------------------------- Menu -------------------------------------\n\n\tElija una opcion:\n\t\t 1> Suma\n\t\t 2> Resta\n\t\t 3> Producto (Multiplicacion)\n\t\t 4> Cociente (Division)	\n\t\t 5> Potencia	\n\t\t 6> Factorial	\n\t\t 7> Seno	\n\t\t 8> Coseno	\n\t\t 9> Tangente	\n\t\t10> Arcoseno (Angulo cuyo Seno)	\n\t\t11> Arcocoseno (Angulo cuyo Coseno)	\n\t\t12> Arcotangente (Angulo cuya Tangente)	\n\t\t14> ZA HOMUWARUDO!	\n\t\t13> Salir	\n\n\tOpcion: ");
	scanf("%i",&Ch);
	switch (Ch){
		case 1:
			Suma(A);
			break;	
		case 2:
			Resta(A);
			break;
		case 3:
			Producto(A);
			break;
		case 4:
			Cociente(A);
			break;
		case 5:
			Potencia(Base);
			break;
		case 6:
			Factorial(Num);
			break;
		case 7:
			Seno(Angulo);
			break;
		case 8:
			Coseno(Angulo);
			break;
		case 9:
			Tangente(Angulo);
			break;
		case 10:
			Arcoseno(A);
			break;
		case 11:
			Arcocoseno (A);
			break;
		case 12:
			Arcotangente(A);
			break;
		case 13:
			break;
		case 14:
			break;
		case 15:
			break;
		default:
			printf("\n\tLa opcion es incorrecta.\n");
			break;
	}
	printf("\n\tEl programa ha finalizado.");
}

float Suma(float A){
	system("cls");
	printf("\n------------------------------------- Suma -------------------------------------\n");
	printf("\n\tIngrese el primer sumando: ");
	scanf("%f",&A);
	printf("\n\tIngrese el segundo sumando: ");
	scanf("%f",&B);
	printf("\n\tEl resultado es: %g", A+B);
	
}

float Resta(float A){
	system("cls");
	printf("\n------------------------------------ Resta -------------------------------------\n");
	printf("\n\tIngrese el primer numero: ");
	scanf("%f",&A);
	printf("\n\tIngrese el segundo numero: ");
	scanf("%f",&B);
	printf("\n\tEl resultado es: %g", A-B);
}

float Producto(float A){
	system("cls");
	printf("\n---------------------------------- Producto ------------------------------------\n");
	printf("\n\tIngrese el primer factor: ");
	scanf("%f",&A);
	printf("\n\tIngrese el segundo factor: ");
	scanf("%f",&B);
	printf("\n\tEl resultado es: %g", A*B);
}


float Cociente(float A){
	system("cls");
	printf("\n---------------------------------- Cociente ------------------------------------\n");
	printf("\n\tIngrese el dividendo: ");
	scanf("%f",&A);
	printf("\n\tIngrese el divisor: ");
	scanf("%f",&B);
	printf("\n\tEl resultado es: %g", A/B);
}


int Factorial(int Num){
	system("cls");
	printf("\n---------------------------------- Factorial -----------------------------------\n");
	printf("\n\tIngrese el numero del cual desea conocer su factorial: ");
	scanf("%i",&Num);
	if (Num>=0){
		for (i=1;i<=Num;i++) {
			Fact=Fact*i;
		}
		printf("\n\tEl factorial de %i es %i\n", Num, Fact);
	}else{
		printf("\n\t%i no tiene factorial.\n", Num);
	}
}

float Potencia(float Base){
	system("cls");
	printf("\n----------------------------------- Potencia -----------------------------------\n");
	printf("\n\tIngrese el numero del cual desea conocer su potencia: ");
	scanf("%f", &Base);
	printf("\n\tIngrese la potencia a la que desea elevar el numero: ");
	scanf("%i", &Exponente);
	if (Base==0 &Exponente<=0){
		printf("\n\tEl numero %g elevado a la potencia %i resulta en una indeterminacion.\n", Base, Exponente, Pot);
	}else if (Exponente>=0){
		for (i=1;i<=Exponente;i++){
			Pot=Pot*Base;
		}
		printf("\n\tEl numero %g elevado a la potencia %i es: %g\n", Base, Exponente, Pot);
	}else{
		for (i=1;i<=-Exponente;i++){
			Pot=Pot/Base;
		}
		printf("\n\tEl numero %g elevado a la potencia %i es: %g\n", Base, Exponente, Pot);
	}
}

float Seno(float Angulo){
	system("cls");
	printf("\n------------------------------------- Seno -------------------------------------\n");
	printf("\n\tIngrese el angulo en grados: ");
	scanf("%f",&Angulo);
	Angulo=(Angulo*PI/180);
	printf("\n\tEl resultado es: %g", sin(Angulo));
}

float Coseno(float Angulo){
	system("cls");
	printf("\n------------------------------------ Coseno ------------------------------------\n");
	printf("\n\tIngrese el angulo en grados: ");
	scanf("%f",&Angulo);
	Angulo=(Angulo*PI/180);
	printf("\n\tEl resultado es: %g", cos(Angulo));
}

float Tangente(float Angulo){
	system("cls");
	printf("\n----------------------------------- Tangente -----------------------------------\n");
	printf("\n\tIngrese el angulo en grados: ");
	scanf("%f",&Angulo);
	Angulo=(Angulo*PI/180);
	printf("\n\tEl resultado es: %g", tan(Angulo));
}

float Arcoseno(float A){
	system("cls");
	printf("\n----------------------------------- Arcoseno -----------------------------------\n");
	printf("\n   Ingrese el valor del seno a partir del cual desea obtener el angulo: ");
	scanf("%f",&A);
	B=(asin(A)*180/PI);
	printf("\n\tEl resultado es: %g", B);
}

float Arcocoseno(float A){
	system("cls");
	printf("\n---------------------------------- Arcocoseno ----------------------------------\n");
	printf("\n   Ingrese el valor del coseno a partir del cual desea obtener el angulo: ");
	scanf("%f",&A);
	B=(acos(A)*180/PI);
	printf("\n\tEl resultado es: %g", B);
}

float Arcotangente(float A){
	system("cls");
	printf("\n--------------------------------- Arcotangente ---------------------------------\n");
	printf("\n   Ingrese el  valor de la tangente a partir de la cual desea obtener el angulo: ");
	scanf("%f",&A);
	B=(atan(A)*180/PI);
	printf("\n\tEl resultado es: %g", B);
}
