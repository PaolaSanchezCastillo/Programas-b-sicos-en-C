/*Fundamentos de programaci�n
  Programa 11-Potencia de un n�mero
  Autor: S�nchez Castillo Paola
  Semestre 2016-1 */

#include<stdio.h>

int num, potencia, res, i;

/**Programa que calcula el resultado
** de elevar un n�mero entero a una
** potencia entera.**/

int main(void){

  printf("Elige el numero: ");
  scanf("%i", &num);
  printf("Elige la potencia: ");
  scanf("%i", &potencia);

  res = 1;
    for(i = 1; i <= potencia; i++){
      res = res*num;
  }

  printf("%i elevado a la %i es: %i", num, potencia, res);

  return 0;
}

