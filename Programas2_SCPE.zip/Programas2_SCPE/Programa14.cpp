/*Fundamentos de programaci�n
  Programa 14-Uso de swtich y char
  para calcular �reas de figuras
   Autor: S�nchez Castillo Paola
  Semestre 2016-1 */

float altura, base, radio, area;
static const float pi = 3.14159265359;
char opt;

/**Programa que calcula el �rea de cuatro figuras
** geom�tricas con datos ingresados por el usuario**/

int main(){
	printf("------------------------------------------------------------\n");
	printf("Programa para calcular el area de las siguientes figuras\n"
					"en unidades al cuadrado:\n");
	printf("------------------------------------------------------------\n");
	printf("\nA-Circulo"
				 "\nB-Cuadrado"
				 "\nC-Rectangulo"
				 "\nD-Triangulo\n\n");
	printf("------------------------------------------------------------\n");
	printf("Elige la opcion que deseas (A-D): ");
	scanf(" %c", &opt);
	printf("------------------------------------------------------------\n");

	switch(opt){
		case 'a':
		case 'A':
			printf("Tu eleccion fue: Circulo.\nIngresa el radio: ");
			scanf("%f", &radio);
			printf("\nEl area es: %.3f\n", pi*radio*radio);
			break;
		case 'b':
		case 'B':
			printf("Tu eleccion fue: Cuadrado.\nIngresa el lado: ");
			scanf("%f", &base);
			printf("\nEl area es: %.3f\n", base*base);
			break;
		case 'c':
		case 'C':
			printf("Tu eleccion fue: Rectangulo.\nIngresa la base: ");
			scanf("%f", &base);
			printf("\nIngresa la altura: ");
			scanf("%f", &altura);
			printf("\nEl area es: %.3f\n", base*altura);
			break;
		case 'd':
		case 'D':
			printf("Tu eleccion fue: Triangulo\nIngresa la altura: ");
			scanf("%f", &altura);
			printf("Ingresa la longitud de la base: ");
			scanf("%f", &base);
			printf("\nEl areas es: %.3f\n", base*altura/2);
			break;
		default:
			printf("Opcion invalidad");
			break;
		}

	printf("------------------------------------------------------------\n");

	return 0;
}

