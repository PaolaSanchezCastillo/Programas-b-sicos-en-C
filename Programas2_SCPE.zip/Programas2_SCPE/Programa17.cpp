/* Programa13-SwitchVolumnesInt
 Autor: S�nchez Castillo Paola
Fecha: 22/10/2015 */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define PI 3.141592

main()
{
int a;
	printf("Ingresa tu edad en a�os:  ");
	scanf("%i",&a);
	switch(a)
{
	case 1 ... 12:
		printf("\nPor tener %i a�os eres un muy peque�a(o)\n", a);
		break;
	case 13 ... 17:
		printf("\nEres carcel por tener %i a�os\n", a);
		break;
	case 18 ... 45:
			printf("Tienes %i a�os, por lo cual si pasas\n", a);
		break;
	default:
	printf("\n%i a�os es demasiado, gracias por paticipar\n", a);
		break;
}
system ("pause");
}
