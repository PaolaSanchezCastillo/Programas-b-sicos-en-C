/*Fundamentos de programaci�n
  Programa 13-Uso de switch para calcular vol�menes de figuras
   Autor: S�nchez Castillo Paola
  Semestre 2016-1 */

#include<stdio.h>

float altura, base, radio, volumen;
static const float pi = 3.14159265359;
int opt;

/**Programa que calcula el volumen de cuatro figuras
** geom�tricas con datos ingresados por el usuario**/

int main(){
	printf("------------------------------------------------------------\n");
	printf("Programa para calcular el volumen de las siguientes figuras:\n");
	printf("------------------------------------------------------------\n");
	printf("\n1-Cilindro"
				 "\n2-Cono"
				 "\n3-Esfera"
				 "\n4-Piramide\n\n");
	printf("------------------------------------------------------------\n");
	printf("Elige el numero de la figura: ");
	scanf("%i", &opt);
	printf("------------------------------------------------------------\n");

	switch(opt){
		case 1:
			printf("Tu eleccion fue: Cilindro.\nIngresa la altura: ");
			scanf("%f", &altura);
			printf("Ingresa el radio de la base: ");
			scanf("%f", &radio);
			printf("\nEl volumen es: %.3f\n", pi*radio*radio*altura);
			break;
		case 2:
			printf("Tu eleccion fue: Cono.\nIngresa la altura: ");
			scanf("%f", &altura);
			printf("Ingresa el radio de la base: ");
			scanf("%f", &radio);
			printf("\nEl volumen es: %.3f\n", pi*radio*radio*altura/3);
			break;
		case 3:
			printf("Tu eleccion fue: Esfera.\nIngresa el radio de la esfera: ");
			scanf("%f", &radio);
			printf("\nEl volumen es: %.3f\n", 4/3*pi*radio*radio*radio);
			break;
		case 4:
			printf("Tu eleccion fue: piramide\nIngresa la altura: ");
			scanf("%f", &altura);
			printf("Ingresa la longitud de la base: ");
			scanf("%f", &base);
			printf("\nEl volumen es: %.3f\n", base*base*altura/3);
			break;
		default:
			break;
		}

	printf("------------------------------------------------------------\n");

	return 0;
}

