/*Fundamentos de programaci�n
  Programa 16-Programa para calcular el factorial
  de un n�mero dado con la estructura while.
  Autor: S�nchez Castillo Paola
  Semestre 2016-1 */

#include<stdio.h>
int num, i;
long fact;

/**Programa que calcula el factorial de un n�mero dado
** haciendo uso de la estructura de control while.
** A pesar de utilizar el tipo de dato long, no se pueden
** calcular factoriales mayores a 20!
**/

int main(void){

  printf("Programa que calcula el factorial de un numero\n");
  printf("------------------------------------------------------\n");
  printf("Indica el numero del que deseas optener el factorial: ");
  scanf("%i", &num);

  fact = 1; //Inicializa la variable del factorial en 1
  i = 1;    //Inicializa la variable contador en 1

  while(i <= num){
    fact = i * fact;
    ++i;
  }

  printf("El factorial del numero %i es: %lli\n", num, fact);

}

