/*Fundamentos de programaci�n
  Programa 19-Repetir un programa con do...while
   Autor: S�nchez Castillo Paola
  Semestre 2016-1 */

#include<stdio.h>

int num, potencia, res, i;
char opt;

/**Programa que calcula el resultado
** de elevar un n�mero entero a una
** potencia entera.
** Despu�s de realizar el c�lculo se da
** la opci�n de repetir el programa.**/

int main(void){

  do{
    printf("Elige el numero: ");
    scanf("%i", &num);
    printf("Elige la potencia: ");
    scanf("%i", &potencia);

    res = 1;
    for(i = 1; i <= potencia; i++){
      res = res*num;
    }

    printf("%i elevado a la %i es: %i", num, potencia, res);

    printf("\n\nRepetir el prograama?(S/N) ");
    scanf(" %c", &opt);
  }while(opt == 's' || opt == 'S');
}

