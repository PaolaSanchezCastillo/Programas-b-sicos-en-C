
#include <stdio.h>
#include <conio.h>

main(){

int num, a, b, d;
	printf("Introduce el numero de renglones para la piramide ");
	scanf("%d",&b);
	
	for(num=1; num<=b; num++){
		for(a=1; a<d; a++)
		printf(" ");
		d --;
			for(a=1; a<=2*num-1; a++)
				printf("*");
				printf("\n");

	}
	return 0;
}
